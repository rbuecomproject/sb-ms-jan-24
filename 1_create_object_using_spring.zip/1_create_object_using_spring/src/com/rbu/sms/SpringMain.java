package com.rbu.sms;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringMain 
{
public static void main(String[] args) {
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	//Student student=new Student();
//	Student student1=(Student)ap.getBean("student");
//	student1.printName();
//	Student student2=(Student)ap.getBean("student");
//	student2.printName();
//	Student student3=(Student)ap.getBean("student");
//	student3.printName();
}
}
