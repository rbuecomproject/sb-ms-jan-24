package com.rbu.sms;

public class Student {
	public Student() {
		System.out.println("Student object created here...");
	}

	String name = "Amit";

	public void printName() {
		System.out.println("STUDENT NAME =" + name);
	}

}
//understand how to create pojo class
