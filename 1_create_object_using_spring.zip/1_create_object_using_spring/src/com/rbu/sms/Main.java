package com.rbu.sms;

public class Main 
{
public static void main(String[] args) 
{
	Student student1=new Student();
	student1.printName();
	Student student2=new Student();
	student2.printName();
	Student student3=new Student();
	student3.printName();
	//3 years
}
}
//create object
